<div class="tab-list">
	<slot></slot>
</div>

<style>
	.tab-list {
		border-bottom: 1px solid var(--gray-border);
		display: flex;
		flex-wrap: wrap;
	}
</style>