<style>
  nav a {
    color: rgba(0, 0, 0, 0.8);
    border-bottom: none;
    text-decoration: none;
  }

  nav ul li {
    margin-bottom: 0.25em;
  }

  nav a:hover {
    text-decoration: underline solid rgba(0, 0, 0, 0.6);
  }

  nav details ul {
    margin-top: 0;
  }

  nav details > a {
    margin-left: 1.06em;
  }

  nav summary,
  nav > div,
  nav details > a {
    display: block;
    outline: none;
    margin-bottom: 0.5em;
  }

  nav > div {
    margin-left: 1.06em;
  }

  nav summary {
    cursor: context-menu;
  }

  nav summary,
  nav > div > a {
    font-size: 13px;
    font-weight: 600;
  }

  /* a.figure-number,
  a.section-number {
    border-bottom-color: hsla(206, 90%, 20%, 0.3);
    text-transform: uppercase;
    font-size: 0.85em;
    color: hsla(206, 90%, 20%, 0.7);
  }

  a.figure-number::before {
    content: "Figure ";
  }

  a.figure-number:hover,
  a.section-number:hover {
    border-bottom-color: hsla(206, 90%, 20%, 0.6);
  } */
</style>

<nav class="l-text toc figcaption">
  <h3>Contents</h3>

  <div>
    <a href="#introduction">Introduction</a>
  </div>

  <details>
    <summary>The Capabilities of Interactive Articles</summary>
    <a href="#interactive-articles">
      <em>navigate to "The Capabilities of Interactive Articles"</em>
    </a>
    <ul>
      <li>
        <a href="#improving-recall">Improving Recall</a>
      </li>
      <li>
        <a href="#improving-engagement">Improving Engagement</a>
      </li>
      <li>
        <a href="#enabling-experience">Enabling Experience</a>
      </li>
      <li>
        <a href="#reducing-cognitive-load">Reducing Cognitive Load</a>
      </li>
      <li>
        <a href="#personalization">Personalization</a>
      </li>
    </ul>
  </details>

  <div>
    <a href="#applications">Applications</a>
  </div>

  <div>
    <a href="#critical-reflections">Critical Reflections</a>
  </div>

  <div>
    <a href="#challenges">Challenges of Interactive Writing</a>
  </div>

  <div>
    <a href="#discussion">Discussion</a>
  </div>

</nav>
